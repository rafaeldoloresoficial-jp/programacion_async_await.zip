﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$
{
    internal class Name
    {
        public string title { get; set; }
        public string first { get; set; }
        public string last { get; set; }
    }
}
