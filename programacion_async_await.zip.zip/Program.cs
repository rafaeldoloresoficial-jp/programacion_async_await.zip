﻿using System;
using System.Net.Http;
using System.Text.Json;
using System.Threading.Tasks;
using System.Collections.Generic;

namespace $safeprojectname$
{
    class Program
    {
        static async Task Main(string[] args)
        {
            bool continuar = true;

            while (continuar)
            {
                try
                {
                    Console.Write("¿Cuántos usuarios deseas mostrar? ");
                    int cantidad = int.Parse(Console.ReadLine());

                    Console.WriteLine("Obteniendo usuarios...\n");

                    HttpClient client = new HttpClient();
                    string url = "https://jsonplaceholder.typicode.com/users";

                    string json = await client.GetStringAsync(url);

                    List<User>? users = JsonSerializer.Deserialize<List<User>>(json);

                    if (users == null)
                    {
                        Console.WriteLine("No se pudieron obtener usuarios.");
                        return;
                    }

                    for (int i = 0; i < cantidad && i < users.Count; i++)
                    {
                        var user = users[i];

                        Console.WriteLine("Nombre: " + user.name);
                        Console.WriteLine("Correo: " + user.email);
                        Console.WriteLine("Ciudad: " + user.address?.city);
                        Console.WriteLine("-----------------------");
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Ocurrió un error: " + ex.Message);
                }

                Console.Write("\n¿Deseas buscar más usuarios? (si/no): ");
                string respuesta = Console.ReadLine().ToLower();

                continuar = respuesta == "si";
                Console.Clear();
            }

            Console.WriteLine("Programa finalizado.");
        }
    }
}